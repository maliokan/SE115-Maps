public class City {
    public String name;

    public City(String name){
        this.name = name;
    }
}
