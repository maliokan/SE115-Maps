public class Routes {
    public City[] route;
    public int totalTime;

    public Routes(City[] route, int totalTime) {
        this.route = route;
        this.totalTime = totalTime;
    }
}
